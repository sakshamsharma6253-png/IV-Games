#!/usr/bin/env python3
"""Simple chess launcher (opens online chess) or placeholder GUI.

Run: python chess.py
"""
import webbrowser
import tkinter as tk


def open_online():
    webbrowser.open('https://lichess.org')


def main():
    root = tk.Tk(); root.title('Chess (Launcher)')
    tk.Label(root, text='Chess - Launcher / Placeholder', padx=16, pady=12).pack()
    tk.Button(root, text='Open lichess.org', command=open_online, width=24).pack(pady=6)
    tk.Button(root, text='Quit', command=root.destroy, width=24).pack(pady=6)
    root.mainloop()


if __name__ == '__main__':
    main()
