"""Bus/Subway Runner - Pygame scaffold

Run with the venv Python created earlier:
  ./.venv/Scripts/python.exe bus_runner.py

Controls: Left/Right arrows or A/D to change lanes.
"""
import random
import pygame
import sys
import os
import wave
import struct
import math
import asyncio  

WIDTH, HEIGHT = 400, 600
LANE_COUNT = 3

class Player:
    def __init__(self, lanes):
        self.lanes = lanes
        self.current = len(lanes) // 2
        self.radius = 20

    @property
    def x(self):
        return self.lanes[self.current]

    @property
    def y(self):
        return HEIGHT - 100

    def move_left(self):
        if self.current > 0:
            self.current -= 1

    def move_right(self):
        if self.current < len(self.lanes) - 1:
            self.current += 1

class Obstacle:
    def __init__(self, x, speed):
        self.x = x
        self.y = -40
        self.w = 50
        self.h = 30
        self.speed = speed

    def update(self, dt):
        self.y += self.speed * dt

    def rect(self):
        return pygame.Rect(self.x - self.w // 2, int(self.y), self.w, self.h)

def ensure_assets():
    assets_dir = os.path.join(os.path.dirname(__file__), 'assets')
    os.makedirs(assets_dir, exist_ok=True)
    beep_path = os.path.join(assets_dir, 'beep.wav')
    crash_path = os.path.join(assets_dir, 'crash.wav')

    def write_tone(path, freq=440, duration=0.12, volume=0.5):
        if os.path.exists(path):
            return
        framerate = 44100
        nframes = int(duration * framerate)
        amp = int(32767 * volume)
        with wave.open(path, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(framerate)
            for i in range(nframes):
                t = i / framerate
                val = int(amp * math.sin(2 * math.pi * freq * t))
                wf.writeframes(struct.pack('<h', val))

    write_tone(beep_path, freq=880, duration=1.14, volume=0.4)
    write_tone(crash_path, freq=120, duration=0.4, volume=0.6)
    return assets_dir, beep_path, crash_path

def load_highscore(path):
    try:
        with open(path, 'r') as f:
            return int(f.read().strip() or 0)
    except Exception:
        return 0

def save_highscore(path, score):
    try:
        with open(path, 'w') as f:
            f.write(str(score))
    except Exception:
        pass

# NAYA: function ko 'async def' banaya gaya hai
async def main():
    pygame.init()
    try:
        pygame.mixer.init()
    except Exception:
        pass

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Bus / Subway Runner - saksham')
    clock = pygame.time.Clock()

    assets_dir, beep_path, crash_path = ensure_assets()
    try:
        beep_snd = pygame.mixer.Sound(beep_path)
    except Exception:
        beep_snd = None
    try:
        crash_snd = pygame.mixer.Sound(crash_path)
    except Exception:
        crash_snd = None

    # lane x positions
    lanes = [int((i + 0.5) * WIDTH / LANE_COUNT) for i in range(LANE_COUNT)]
    player = Player(lanes)

    obstacles = []
    particles = []
    spawn_timer = 0.0
    spawn_interval = 1.0
    obstacle_speed = 140

    score = 0
    state = 'MENU'  # MENU, PLAYING, RESTARTING
    restart_timer = 0.0

    font = pygame.font.SysFont('Arial', 20)
    large_font = pygame.font.SysFont('Arial', 36)

    hs_path = os.path.join(os.path.dirname(__file__), 'highscore.txt')
    highscore = load_highscore(hs_path)

    while True:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if state == 'MENU' and event.key == pygame.K_SPACE:
                    state = 'PLAYING'
                    obstacles.clear()
                    particles.clear()
                    score = 0
                    spawn_interval = 1.0
                    obstacle_speed = 140
                    player.current = len(lanes) // 2
                elif state == 'PLAYING':
                    if event.key in (pygame.K_LEFT, pygame.K_a):
                        player.move_left()
                        if beep_snd:
                            beep_snd.play()
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        player.move_right()
                        if beep_snd:
                            beep_snd.play()
                elif state in ('RESTARTING', 'GAMEOVER') and event.key == pygame.K_SPACE:
                    state = 'MENU'

        if state == 'PLAYING':
            # Spawn obstacles
            spawn_timer += dt
            if spawn_timer >= spawn_interval:
                spawn_timer = 0.0
                lane_x = random.choice(lanes)
                w = random.choice([40, 50, 70])
                h = random.choice([25, 30, 40])
                ob = Obstacle(lane_x, obstacle_speed)
                ob.w = w
                ob.h = h
                obstacles.append(ob)
                if spawn_interval > 0.35:
                    spawn_interval *= 0.987
                obstacle_speed += 0.5

            # Update obstacles
            for ob in list(obstacles):
                ob.update(dt)
                if ob.y > HEIGHT + 100:
                    obstacles.remove(ob)
                    score += 1

            # Collision check
            player_rect = pygame.Rect(player.x - player.radius, player.y - player.radius,
                                      player.radius * 2, player.radius * 2)
            hit = None
            for ob in obstacles:
                if player_rect.colliderect(ob.rect()):
                    hit = ob
                    break
            if hit:
                for i in range(20):
                    particles.append([
                        player.x,
                        player.y,
                        random.uniform(-200, 200),
                        random.uniform(-200, 0),
                        random.uniform(0.5, 1.2),
                    ])
                if crash_snd:
                    crash_snd.play()
                if score > highscore:
                    highscore = score
                    save_highscore(hs_path, highscore)
                state = 'RESTARTING'
                restart_timer = 2.0

        # update particles
        for p in list(particles):
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 400 * dt  # gravity
            p[4] -= dt
            if p[4] <= 0:
                particles.remove(p)

        # handle automatic restart countdown
        if state == 'RESTARTING':
            restart_timer -= dt
            if restart_timer <= 0:
                obstacles.clear()
                particles.clear()
                score = 0
                spawn_interval = 1.0
                obstacle_speed = 140
                player.current = len(lanes) // 2
                state = 'PLAYING'

        # Draw
        screen.fill((50, 70, 30))

        # Watermark / credit
        tw = font.render("Made by saksham", True, (0, 255, 0))
        screen.blit(tw, (10, 10))

        # Lane dividers
        for i in range(1, LANE_COUNT):
            x = i * WIDTH // LANE_COUNT
            pygame.draw.rect(screen, (51, 51, 51), (x - 1, 0, 2, HEIGHT))

        # Draw player
        player_surf = pygame.Surface((player.radius * 2 + 6, player.radius * 2 + 6), pygame.SRCALPHA)
        pygame.draw.circle(player_surf, (0, 200, 0, 180), (player.radius + 3, player.radius + 3), player.radius + 3)
        pygame.draw.circle(player_surf, (0, 255, 0), (player.radius + 3, player.radius + 3), player.radius)
        screen.blit(player_surf, (player.x - player.radius - 3, player.y - player.radius - 3))

        # Draw obstacles
        for ob in obstacles:
            pygame.draw.rect(screen, (200, 50, 50), ob.rect(), border_radius=4)

        # Draw particles
        for p in particles:
            alpha = max(0, int(255 * p[4]))
            col = (255, 180, 60, alpha)
            surf = pygame.Surface((4, 4), pygame.SRCALPHA)
            surf.fill(col)
            screen.blit(surf, (int(p[0]), int(p[1])))

        # HUD
        score_surf = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_surf, (WIDTH - 120, 10))
        hs_surf = font.render(f"High: {highscore}", True, (200, 200, 100))
        screen.blit(hs_surf, (WIDTH - 120, 34))

        if state == 'MENU':
            title = large_font.render('Bus / Subway Runner', True, (255, 255, 255))
            prompt = font.render('Press SPACE to start', True, (200, 200, 200))
            credit = font.render('Made by saksham', True, (150, 200, 150))
            screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 40))
            screen.blit(prompt, (WIDTH // 2 - prompt.get_width() // 2, HEIGHT // 2 + 10))
            screen.blit(credit, (WIDTH // 2 - credit.get_width() // 2, HEIGHT // 2 + 40))
        elif state == 'GAMEOVER':
            go = large_font.render('Game Over', True, (255, 80, 80))
            sc = font.render(f'Your score: {score}', True, (255, 255, 255))
            rpt = font.render('Press SPACE to return to menu', True, (200, 200, 200))
            screen.blit(go, (WIDTH // 2 - go.get_width() // 2, HEIGHT // 2 - 40))
            screen.blit(sc, (WIDTH // 2 - sc.get_width() // 2, HEIGHT // 2 + 10))
            screen.blit(rpt, (WIDTH // 2 - rpt.get_width() // 2, HEIGHT // 2 + 40))

        pygame.display.flip()
        
        # NAYA: Yeh line browser ko hang hone se rokti hai
        await asyncio.sleep(0)

# NAYA: asyncio.run() ke through function call kiya gaya hai
if __name__ == '__main__':
    asyncio.run(main())