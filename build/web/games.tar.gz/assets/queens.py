#!/usr/bin/env python3
"""N-Queens visualizer (Tkinter)

Run: python queens.py
"""
import tkinter as tk


def solve_n_queens(N):
    out = [ -1 ] * N
    cols = [False]*N
    d1 = [False]*(2*N)
    d2 = [False]*(2*N)

    def go(r):
        if r==N:
            return out.copy()
        for c in range(N):
            if not cols[c] and not d1[r+c] and not d2[r-c+N-1]:
                out[r]=c
                cols[c]=d1[r+c]=d2[r-c+N-1]=True
                res = go(r+1)
                if res:
                    return res
                cols[c]=d1[r+c]=d2[r-c+N-1]=False
                out[r]=-1
        return None

    return go(0)


class QueensApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('N-Queens Visualizer')
        frame = tk.Frame(self.root, padx=10, pady=10)
        frame.pack()

        tk.Label(frame, text='N:').grid(row=0, column=0)
        self.nvar = tk.IntVar(value=8)
        self.nmenu = tk.Spinbox(frame, from_=4, to=12, textvariable=self.nvar, width=4)
        self.nmenu.grid(row=0, column=1)
        tk.Button(frame, text='Solve', command=self.on_solve).grid(row=0,column=2, padx=6)
        tk.Button(frame, text='Random', command=self.on_random).grid(row=0,column=3, padx=6)

        self.canvas = tk.Canvas(self.root, width=360, height=360)
        self.canvas.pack(padx=10, pady=10)

    def draw(self, sol):
        N = self.nvar.get()
        self.canvas.delete('all')
        cell = 360 / N
        for r in range(N):
            for c in range(N):
                x0,y0 = c*cell, r*cell
                color = '#f0f0f0' if (r+c)%2==0 else '#a0a0a0'
                self.canvas.create_rectangle(x0,y0,x0+cell,y0+cell, fill=color, outline='black')
        if sol:
            for r,c in enumerate(sol):
                x = c*cell + cell/2
                y = r*cell + cell/2
                self.canvas.create_text(x,y, text='♛', font=('Arial', int(cell/1.6)), fill='#b00')

    def on_solve(self):
        N = int(self.nvar.get())
        sol = solve_n_queens(N)
        if sol:
            self.draw(sol)
        else:
            tk.messagebox.showinfo('No solution', 'No solution found')

    def on_random(self):
        import random
        N = int(self.nvar.get())
        # randomized backtracking
        out = [-1]*N
        cols=[False]*N; d1=[False]*(2*N); d2=[False]*(2*N)

        def go(r):
            if r==N: return out.copy()
            order = list(range(N)); random.shuffle(order)
            for c in order:
                if not cols[c] and not d1[r+c] and not d2[r-c+N-1]:
                    out[r]=c; cols[c]=d1[r+c]=d2[r-c+N-1]=True
                    res=go(r+1)
                    if res: return res
                    cols[c]=d1[r+c]=d2[r-c+N-1]=False; out[r]=-1
            return None

        sol = go(0)
        if sol: self.draw(sol)
        else: tk.messagebox.showinfo('No solution', 'Could not find a solution')

    def run(self):
        self.root.mainloop()


if __name__ == '__main__':
    app = QueensApp()
    app.run()
