#!/usr/bin/env python3
"""Mini Sudoku (4x4) Tkinter game

Run: python minisudoku.py
"""
import tkinter as tk
import random


def generate_full():
    base = [ [1,2,3,4], [3,4,1,2], [2,1,4,3], [4,3,2,1] ]
    rows = base[:]
    random.shuffle(rows)
    idx = [0,1,2,3]
    random.shuffle(idx)
    out = [[ rows[r][idx[c]] for c in range(4)] for r in range(4)]
    return out


def make_puzzle():
    full = generate_full()
    puzzle = [row[:] for row in full]
    removals = 6 + random.randint(0,3)
    for _ in range(removals):
        i = random.randrange(4); j = random.randrange(4)
        puzzle[i][j] = 0
    return puzzle, full


class MiniSudokuApp:
    def __init__(self):
        self.root = tk.Tk(); self.root.title('Mini Sudoku 4x4')
        frame = tk.Frame(self.root, padx=10, pady=10); frame.pack()
        tk.Label(frame, text='Mini Sudoku (4×4)').grid(row=0,column=0,columnspan=4)
        self.entries = [[None]*4 for _ in range(4)]
        self.puzzle = None; self.solution = None
        grid = tk.Frame(frame); grid.grid(row=1,column=0,columnspan=4)
        for r in range(4):
            for c in range(4):
                e = tk.Entry(grid, width=2, justify='center', font=('Arial',18))
                e.grid(row=r,column=c,padx=4,pady=4)
                self.entries[r][c]=e

        tk.Button(frame, text='New', command=self.new).grid(row=2,column=0,padx=6)
        tk.Button(frame, text='Check', command=self.check).grid(row=2,column=1,padx=6)
        tk.Button(frame, text='Solve', command=self.solve).grid(row=2,column=2,padx=6)
        tk.Button(frame, text='Quit', command=self.root.destroy).grid(row=2,column=3,padx=6)
        self.new()

    def new(self):
        p, s = make_puzzle(); self.puzzle=p; self.solution=s
        for r in range(4):
            for c in range(4):
                e = self.entries[r][c]
                if p[r][c]:
                    e.delete(0,'end'); e.insert(0,str(p[r][c])); e.config(state='disabled',disabledforeground='black')
                else:
                    e.config(state='normal'); e.delete(0,'end')

    def collect(self):
        b = [[0]*4 for _ in range(4)]
        for r in range(4):
            for c in range(4):
                val = self.entries[r][c].get().strip()
                b[r][c] = int(val) if val.isdigit() else 0
        return b

    def check(self):
        b = self.collect(); ok = True
        for r in range(4):
            for c in range(4):
                if b[r][c] != self.solution[r][c]: ok=False
        if ok:
            tk.messagebox.showinfo('Correct','Puzzle solved correctly!')
            self.new()
        else:
            tk.messagebox.showinfo('Not yet','Some cells are incorrect or empty.')

    def solve(self):
        for r in range(4):
            for c in range(4):
                e = self.entries[r][c]
                e.config(state='normal'); e.delete(0,'end'); e.insert(0,str(self.solution[r][c])); e.config(state='disabled')

    def run(self):
        self.root.mainloop()


if __name__ == '__main__':
    import tkinter.messagebox
    app = MiniSudokuApp(); app.run()
