import tkinter as tk
from tkinter import messagebox
import json
import os


class TicTacToe:


	def __init__(self, root):
		self.root = root
		root.title('Tic Tac Toe - saksham')

		
		self.bg_canvas = tk.Canvas(root, highlightthickness=0)
		self.bg_canvas.place(relx=0, rely=0, relwidth=1, relheight=1)
		# redraw background when window resizes
		self.root.bind('<Configure>', lambda e: self.draw_background(self.theme_var.get() if hasattr(self, 'theme_var') else 'Dark'))

		
		self.board = [''] * 9
		self.current = 'X'
		self.buttons = []

		
		self.score_file = os.path.join(os.path.dirname(__file__), 'tic_tac_score.json')
		self.scores = self.load_scores()

		
		self.status = tk.Label(root, text='Turn: X', font=('Arial', 14))
		self.status.grid(row=0, column=0, pady=(8,0))

		
		self.opponent_var = tk.StringVar(value='Human')
		self.opponent_menu = tk.OptionMenu(root, self.opponent_var, 'Human', 'AI (Easy)', 'AI (Hard)')
		self.opponent_menu.config(width=10)
		self.opponent_menu.grid(row=0, column=1, padx=(6,0))

		
		self.score_x_lbl = tk.Label(root, text=f"X wins: {self.scores.get('X', 0)}", font=('Arial', 11))
		self.score_x_lbl.grid(row=0, column=2, sticky='w', padx=(6, 0))
		self.score_o_lbl = tk.Label(root, text=f"O wins: {self.scores.get('O', 0)}", font=('Arial', 11))
		self.score_o_lbl.grid(row=1, column=2, sticky='w', padx=(6, 0))
		self.score_d_lbl = tk.Label(root, text=f"Draws: {self.scores.get('D', 0)}", font=('Arial', 11))
		self.score_d_lbl.grid(row=2, column=2, sticky='w', padx=(6, 0))

		
		self.theme_var = tk.StringVar(value='Dark')
		self.theme_menu = tk.OptionMenu(root, self.theme_var, 'Dark', 'Light', command=self.apply_theme)
		self.theme_menu.config(width=8)
		self.theme_menu.grid(row=1, column=1, padx=(6,0))

		
		self.credit = tk.Label(root, text='Made by saksham', fg='#0a0', font=('Arial', 9))
		self.credit.grid(row=5, column=0, columnspan=3, pady=(6, 8))

		
		self.themes = {
			'Dark': {'bg': "#101010", 'fg': "#ffffff", 'btn': "#202020", 'btn_fg': '#00ff00'},
			'Light': {'bg': "#f0f0f0", 'fg': "#000000", 'btn': "#ffffff24", 'btn_fg': '#006400'},
		}

		self.apply_theme(self.theme_var.get())

		
		for i in range(9):
			b = tk.Button(root, text='', width=6, height=3, font=('Arial', 24),
						  command=lambda i=i: self.on_click(i))
			b.grid(row=1 + i // 3, column=i % 3, padx=4, pady=4)
			self.buttons.append(b)

		
		self.reset_btn = tk.Button(root, text='Reset', command=self.reset)
		self.reset_btn.grid(row=6, column=0, columnspan=3, pady=(6, 10))

		
		self.exit_btn = tk.Button(root, text='Exit', command=self.on_close)
		self.exit_btn.grid(row=7, column=0, columnspan=3, pady=(0, 10))

		
		self.root.protocol('WM_DELETE_WINDOW', self.on_close)

	def on_click(self, i):
		"""Handle a cell click: place mark, check result, switch turn."""
		if self.board[i] != '':
			return
		self.board[i] = self.current
		self.buttons[i]['text'] = self.current
		self.buttons[i]['state'] = 'disabled'

		
		if self.check_win():
			return

		
		if all(self.board):
			self.scores['D'] = self.scores.get('D', 0) + 1
			self.save_scores()
			self.update_score_labels()
			messagebox.showinfo('Draw', 'Match ended in a draw')
			self.root.after(800, self.reset)
			return

		
		self.current = 'O' if self.current == 'X' else 'X'
		self.status['text'] = f'Turn: {self.current}'

		
		opp = self.opponent_var.get()
		if self.current == 'O' and opp != 'Human':
			self.root.after(250, self.ai_move)

	def check_win(self):
		"""Check all winning lines; update scoreboard on win."""
		wins = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
				(0, 3, 6), (1, 4, 7), (2, 5, 8),
				(0, 4, 8), (2, 4, 6)]
		for a, b, c in wins:
			if self.board[a] and self.board[a] == self.board[b] == self.board[c]:
			
				for idx in (a, b, c):
					self.buttons[idx]['bg'] = "#1500ff"
				winner = self.board[a]
				# update persistent scoreboard
				self.scores[winner] = self.scores.get(winner, 0) + 1
				self.save_scores()
				self.update_score_labels()
				messagebox.showinfo('Winner', f'{winner} wins!')
				# reset after short delay so player can see result
				self.root.after(1000, self.reset)
				return True
		return False

	def reset(self):
		"""Reset the board for a new game."""
		self.board = [''] * 9
		self.current = 'X'
		self.status['text'] = 'Turn: X'
		for b in self.buttons:
			b['text'] = ''
			b['state'] = 'normal'
			b['bg'] = 'SystemButtonFace'
		# apply theme to buttons after reset
		self.apply_theme(self.theme_var.get())

	def ai_move(self):
		"""AI move handler: Easy=random, Hard=minimax"""
		available = [i for i, v in enumerate(self.board) if v == '']
		if not available:
			return
		mode = self.opponent_var.get()
		if mode == 'AI (Easy)':
			import random
			choice = random.choice(available)
		else:
			# minimax for 'O' (AI) maximizing O
			choice = self.minimax_choice()
		# Place move
		self.board[choice] = self.current
		self.buttons[choice]['text'] = self.current
		self.buttons[choice]['state'] = 'disabled'
		# Check win/draw and switch turn
		if self.check_win():
			return
		if all(self.board):
			self.scores['D'] = self.scores.get('D', 0) + 1
			self.save_scores()
			self.update_score_labels()
			messagebox.showinfo('Draw', 'Match ended in a draw')
			self.root.after(800, self.reset)
			return
		self.current = 'X'
		self.status['text'] = f'Turn: {self.current}'

	def minimax_choice(self):
		"""Return best move index for 'O' using minimax."""
		def winner(board):
			wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
			for a,b,c in wins:
				if board[a] and board[a] == board[b] == board[c]:
					return board[a]
			return None

		def minimax(board, player):
			w = winner(board)
			if w == 'O':
				return (1, None)
			if w == 'X':
				return (-1, None)
			if all(board):
				return (0, None)
			if player == 'O':
				best = (-999, None)
				for i in range(9):
					if board[i] == '':
						board[i] = 'O'
						score, _ = minimax(board, 'X')
						board[i] = ''
						if score > best[0]:
							best = (score, i)
				return best
			else:
				best = (999, None)
				for i in range(9):
					if board[i] == '':
						board[i] = 'X'
						score, _ = minimax(board, 'O')
						board[i] = ''
						if score < best[0]:
							best = (score, i)
				return best

		_, move = minimax(self.board[:], 'O')
		return move if move is not None else [i for i,v in enumerate(self.board) if v==''][0]

	def apply_theme(self, name):
		t = self.themes.get(name, self.themes['Dark'])
		try:
			self.root.configure(bg=t['bg'])
		except Exception:
			pass
		
		try:
			self.draw_background(name)
		except Exception:
			pass
		for b in self.buttons:
			b.configure(bg=t['btn'], fg=t['btn_fg'], activebackground=t['btn'], relief='raised', bd=3)
		self.status.configure(bg=t['bg'], fg=t['fg'])
		self.score_x_lbl.configure(bg=t['bg'], fg=t['fg'])
		self.score_o_lbl.configure(bg=t['bg'], fg=t['fg'])
		self.score_d_lbl.configure(bg=t['bg'], fg=t['fg'])
		self.credit.configure(bg=t['bg'])
		if hasattr(self, 'reset_btn'):
			self.reset_btn.configure(bg=t['btn'], fg=t['btn_fg'], activebackground=t['btn'], relief='groove')
		if hasattr(self, 'exit_btn'):
			self.exit_btn.configure(bg=t['btn'], fg=t['btn_fg'], activebackground=t['btn'], relief='groove')

	def on_close(self):
		"""Safe window close handler."""
		try:
			self.root.destroy()
		except Exception:
			pass

	def load_scores(self):
		try:
			if os.path.exists(self.score_file):
				with open(self.score_file, 'r') as f:
					return json.load(f)
		except Exception:
			pass
		return {'X': 0, 'O': 0, 'D': 0}

	def save_scores(self):
		try:
			with open(self.score_file, 'w') as f:
				json.dump(self.scores, f)
		except Exception:
			pass

	def draw_background(self, name):
		"""Draw a simple vertical gradient on the background canvas for the selected theme."""
		if not hasattr(self, 'bg_canvas'):
			return
		t = self.themes.get(name, self.themes['Dark'])
		
		if name == 'Dark':
			c1, c2 = '#0b0b0b', '#1a1a2a'
		else:
			c1, c2 = '#f7f7f8', '#e8e8ea'
		
		w = max(200, self.root.winfo_width())
		h = max(200, self.root.winfo_height())
		steps = 24
		self.bg_canvas.delete('bg')
		for i in range(steps):
			r = int(int(c1[1:3], 16) + (int(c2[1:3], 16) - int(c1[1:3], 16)) * i / (steps - 1))
			g = int(int(c1[3:5], 16) + (int(c2[3:5], 16) - int(c1[3:5], 16)) * i / (steps - 1))
			b = int(int(c1[5:7], 16) + (int(c2[5:7], 16) - int(c1[5:7], 16)) * i / (steps - 1))
			col = f'#{r:02x}{g:02x}{b:02x}'
			y0 = int(i * h / steps)
			y1 = int((i + 1) * h / steps)
			self.bg_canvas.create_rectangle(0, y0, w, y1, outline='', fill=col, tags='bg')
		# canvas is placed before other widgets; no explicit lowering needed

	def update_score_labels(self):
		self.score_x_lbl['text'] = f"X wins: {self.scores.get('X', 0)}"
		self.score_o_lbl['text'] = f"O wins: {self.scores.get('O', 0)}"
		self.score_d_lbl['text'] = f"Draws:  {self.scores.get('D', 0)}"


def main():
	root = tk.Tk()
	app = TicTacToe(root)
	root.resizable(False, False)
	root.mainloop()


if __name__ == '__main__':
	main()

