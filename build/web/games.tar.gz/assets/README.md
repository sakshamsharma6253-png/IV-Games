ivgames — Static game site for GitHub Pages

This repository contains a small static site (in the `web/` folder) with several lightweight browser games:

- Bus / Subway Runner (demo + Pygame script)
- Tic‑Tac‑Toe (AI easy/hard)
- Mini Sudoku (4×4)
- N‑Queens visualizer
- Chess (placeholder)

Goal: deploy the `web/` folder to GitHub Pages as a free static site and map a custom domain (ivgames.com).

Quick deploy steps (Git + GitHub)

1. Create a new GitHub repository named `ivgames` (or any name).
2. From your `d:\games` folder run:

```powershell
git init
git add .
git commit -m "Initial site"
# create remote repo on GitHub and add as origin, or use GitHub UI to create repo then:
git remote add origin https://github.com/<your-username>/ivgames.git
git branch -M main
git push -u origin main
```

3. In the repository on GitHub: Settings → Pages → Source: `main` branch / `/ (root)` and Save.

4. GitHub Pages will serve files from the repository root. The `web/` folder is already the site content — if you prefer, move its files to the repository root before pushing.

Custom domain (ivgames.com)

I added a `CNAME` file with `ivgames.com` (already in the repo). To map the domain live, configure DNS at your domain registrar:

- If you want the apex domain (`ivgames.com`) to point to GitHub Pages, add A records to GitHub's IPs:
  - 185.199.108.153
  - 185.199.109.153
  - 185.199.110.153
  - 185.199.111.153

- For the `www` subdomain, add a CNAME record pointing to:
  - `<your-github-username>.github.io`

After DNS change, GitHub Pages will provision TLS (may take a few minutes to hours).

If you prefer, you can host the repo on GitHub and I can help push the `web/` content into the repo and finalize the Pages settings. Tell me your GitHub username if you want me to prepare the repo content for you to push.

Notes

- This approach is free (GitHub Pages). You still need to purchase the domain if you want `ivgames.com` (the hosting is free).
- If you don't want to use a custom domain, your site will be available at `https://<your-username>.github.io/ivgames/` after publishing.

Install desktop dependencies (Pygame)

If you want to run the Pygame script `bus_runner.py` locally, install Python 3.10+ and the dependencies:

PowerShell:

```powershell
.
# from d:\games
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
# if pip fails for pygame on Python 3.14:
pip install pygame-ce
```

Windows (CMD):

```bat
install_deps.bat
```

Or run the PowerShell helper:

```powershell
.
\install_deps.ps1
```

Then start the web server for the static site (optional):

```powershell
python app.py
# open http://127.0.0.1:5000/hub.html
```
